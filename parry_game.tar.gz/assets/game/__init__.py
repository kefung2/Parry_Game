"""Parry Game package."""
